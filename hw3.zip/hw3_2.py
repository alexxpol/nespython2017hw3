import numpy as np
X = np.random.randn(100,3)
#%%
X = np.random.randn(100,3)
y1 = X.dot(np.array([1,2,3]))+np.random.randn(100)
X.shape[0]
X.shape[1]

z = np.dot(y1,X)
#%% Task 1
class OLS(object):
     
    def __init__(self, y, X):
        self.X = X
        self.y = y
        self.Inv = np.linalg.inv(np.dot(self.X.transpose(),self.X))
        self.beta = np.dot(np.dot(self.Inv,self.X.transpose()),self.y)
        self.sigma_beta =np.dot((self.y-np.dot(self.X,self.beta)).transpose(),(self.y-np.dot(self.X,self.beta)))/(self.X.shape[0]-self.X.shape[1])
        self.V = np.dot(self.sigma_beta,self.Inv)
        
    def predict(self, row):
        self.prediction = np.dot(row,self.beta)
        self.error = self.sigma_beta*(1+np.dot(np.dot(row,self.Inv),row.transpose()))
        return (self.prediction, self.error)
#%%
import matplotlib as mpl   
import matplotlib.pyplot as plt 
from scipy import stats
#%% Task 2
size =200

beta = np.random.rand(10)
x = np.random.uniform(-5,5,size)
u = np.random.normal(0, 10, size=(size))
y2= np.zeros(size)
X2 = np.zeros((size,10))
y_predict = np.zeros((size,4))
y_high = np.zeros((size))
error = np.zeros((size,4))
y_low = np.zeros((size))

for i in range(0,size):
    for k in range (0,10):
        y2[i] = y2[i] + beta[k]*(np.power(x[i],k)/np.math.factorial(k))
        X2[i,k] = np.power(x[i],k)/np.math.factorial(k)
    y2[i] = y2[i]+u[i]
mpl.pyplot.scatter(x,y2)
plt.xlabel('xi')
plt.ylabel('yi')
plt.savefig('/Users/alenasemanina/Desktop/picture.pdf')
plt.show()


mpl.pyplot.scatter(x,y2)
for i in range(0,size):
    for k in range(0,4):
        model1 = OLS(y2,X2[:,0:k+2])
        error[i,k] = model1.predict(X2[:,0:k+2][i,:])[1]
        y_predict[i,k] = model1.predict(X2[:,0:k+2][i,:])[0]
    y_high[i] = y_predict[i,3] - stats.t.ppf(0.05,200)*np.sqrt(error[i,3])
    y_low[i] = y_predict[i,3] + stats.t.ppf(0.05,200)*np.sqrt(error[i,3])
    
o = np.argsort(x)
plt.plot(x[o],y_predict[:,:][o])
plt.legend(('K=1', 'K=2', 'K=3', 'K=4'))
plt.xlabel('xi')
plt.ylabel('yi')
plt.savefig('/Users/alenasemanina/Desktop/picture1.pdf')
plt.show()


mpl.pyplot.scatter(x,y2)
o = np.argsort(x)
plt.plot(x[o],y_predict[:,3][o], color = 'orange')
plt.legend(('K=1', 'scatters'))
plt.xlabel('xi')
plt.ylabel('yi')
plt.fill_between(x[o],y_high[o],y_low[o],facecolor='grey', alpha=0.3)
plt.savefig('/Users/alenasemanina/Desktop/picture2.pdf')
plt.show()



# Нужно оформить в Латехе с вставкой картинок, внимательно к шрифтам, как выгружать картинки из питона?
# Квантиль поменять на стьюдента
# проверить степени свободы
#%% Task 3

A = np.random.normal(0, 1, size=(100,100))
Exp = np.zeros((100))
Exp_high = np.zeros((100))
Exp_low = np.zeros((100)) 
Logic = np.zeros((100),dtype = bool)
Var = np.ones((100))
a = 0

for i in range(100):
    Exp[i] = np.mean(A[:,i])
    Var[i] = np.abs(np.var(A[:,i]))/(100-1)
    Exp_high[i] = Exp[i] - stats.t.ppf(0.05,100)*np.sqrt(Var[i])
    Exp_low[i]  = Exp[i] + stats.t.ppf(0.05,100)*np.sqrt(Var[i])
    #print(i,(Exp_high[i],Exp_low[i]))
    if (0 < Exp_high[i]) and (0 > Exp_low[i]):
        Logic[i] = True
        a = a + 1
    else: 
        Logic[i] = False
print(Logic,'\nnumber of True = ', a)
    
#%%
import pandas as pd
path = '/Users/alenasemanina/Desktop/nespython2017hw2-master/goalies-2014-2016.csv'
#%% Task 4_1
table = pd.read_csv(path, 'Sheet1',delimiter = ';', header = 0, index_col = 0) 
print(table.iloc[:5,:6])
#%% Task 4_2
table1 = table.copy()
Percentage = np.zeros(279)
Deviation = np.zeros(279)
for i in range(1,279):
    Percentage[i] = np.round(table1['saves'].iloc[i]/table1['shots_against'].iloc[i],12)
    Deviation[i] = np.abs(Percentage[i] - table1['save_percentage'].iloc[i])

print(max(Deviation))          
             
#%% Task 4_3
table2 = table.copy()
Mean = np.zeros((3))
Deviation1 = np.zeros((3))


Mean[0] = np.mean(table2['games_played'])
Deviation1[0] = np.sqrt(np.var(table2['games_played'])/(279-1))
Mean[1] = np.mean(table2['goals_against'])
Deviation1[1] = np.sqrt(np.var(table2['goals_against'])/(279-1))
Mean[2] = np.mean(table['save_percentage'])
Deviation1[2] = np.sqrt(np.var(table2['save_percentage'])/(279-1))

print(' games_played    :', 'Mean = ', Mean[0], 'Std_div = ', Deviation1[0],'\n',
      'goals_against   :', 'Mean = ', Mean[1], 'Std_div = ', Deviation1[1],'\n',
      'save_percentage :', 'Mean = ', Mean[2], 'Std_div = ', Deviation1[2])

#%% Task 4_4
table3 = table.copy()
table3.iloc[[table3['save_percentage'][table3['games_played']>40][table3['season']=='2016-17'].idxmax()-1]][['player','save_percentage']]
#%% Task 4_5
table4 = table.copy()

id1 = table4['saves'][table4['season']=='2016-17'].idxmax() - 1
id2 = table4['saves'][table4['season']=='2015-16'].idxmax() - 1
id3 = table4['saves'][table4['season']=='2014-15'].idxmax() - 1

table4.iloc[[id1,id2,id3]][['season','player','saves']] 

#%% task 4_6
table5 = table.copy()

for i in range(1,280):
    if table5['wins'][i] < 30:
        table5 = table5.drop(i)
        
table6 = table5.groupby('player').sum()
id4 = table6['wins'][table6['wins']>90]
print(id4)


        








